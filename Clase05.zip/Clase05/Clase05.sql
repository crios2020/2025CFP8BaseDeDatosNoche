-- Active: 1756936173008@@127.0.0.1@3306@negocio
       
-- Laboratorio 

-- Usando la base de datos negocio.
use negocio;
-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
insert into clientes values 
	(null,'Ana','Perez','634643','Lima 222',null),
    (null,'Mario','Perez','5377657','Viel 23423',null),
    (null,'Susana','Perez','6474567','Maipu 231',null),
    (null,'Lujan','Perez','47467','Paso 231',null),
    (null,'Martin','Perez','4747','Medrano 24332',null);

-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
insert into clientes (nombre,apellido,direccion) values
	('Ana','Perez','Lima 222'),
    ('Mario','Perez','Viel 23423'),
    ('Susana','Perez','Maipu 231'),
    ('Lujan','Perez','Paso 231'),
    ('Martin','Perez','Medrano 24332');

-- 3-	Actualizar el nombre del cliente 1 a Jose.
update clientes set nombre='Jose' where codigo=1;
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
update clientes set nombre='Pablo', apellido='Fuentes', cuit='20-21053119-0' where codigo=3;
-- 5-	Actualizar todos los comentarios NULL  a ''.
update clientes set comentarios='' where comentarios is null;

set sql_safe_updates=0;				-- desabilita la protección safe_updates
-- set sql_safe_updates=1;				-- habilito la protección safe_updates

-- 6-	Eliminar los clientes con apellido Perez.
delete from clientes where apellido='Perez';
-- 7-	Eliminar los clientes con CUIT Terminan en 0.
delete from clientes where cuit like '%0';

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
update articulos set precio=round(precio*1.2,2) where precio<=50;
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
update articulos set precio=round(precio*1.15,2) where precio>50;
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
update articulos set precio=round(precio*0.95,2) where precio>200;
-- 	11- Eliminar los artículos con stock menor a 0.
delete from articulos where stock<0;

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
alter table articulos add stockMinimo int;
alter table articulos add stockMaximo int;
describe articulos;

--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
select * from articulos;
update articulos set stockMinimo=25, stockMaximo=60;
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
select codigo, nombre, precio, stock, stockMaximo-stock from articulos
	where stock<stockMinimo;
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
select codigo, nombre, precio, stock, precio*stock valor_total from articulos;
select replace(round(sum(precio*stock),2),'.',',') valor_total from articulos;
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.
select replace(round(sum(precio*stock)*1.21,2),'.',',') valor_total_con_iva from articulos;

select * from clientes;
-- Funciones de agrupamiento

-- Función max(arg) 	arg: número, texto, fecha
select max(monto) from facturas;
select max(monto) monto_máximo from facturas;
select max(fecha) ultima_factura from facturas;
select max(nombre) ultimo_nombre from clientes;

-- Función min(arg)		arg: número, texto, fecha
select min(monto) monto_mínimo from facturas;
select min(fecha) primer_fecha from facturas;
select min(nombre) primer_nombre from clientes;

-- función sum(arg)		arg: número
select sum(monto) total_facturado from facturas;
select replace(round(sum(monto),2),'.',',') total_facturado from facturas;
select sum(precio*stock) valor_total from articulos;
select replace(round(sum(precio*stock),2),'.',',') valor_total from articulos;

-- función avg(arg) 	arg: número
select avg(monto) valor_promedio from facturas;
select replace(round(avg(monto),2),'.',',') valor_promedio from facturas;

-- función count(*)
insert into clientes (nombre, apellido) values ('Leo','Vargas');

select count(*) cantidad from facturas;
select count(*) cantidad from clientes;				-- 81
select count(direccion) cantidad from clientes;		-- 80
select * from clientes where direccion is null;

-- Group by
select letra, sum(monto) total from facturas where letra='A';
select letra, sum(monto) total from facturas where letra='B';
select letra, sum(monto) total from facturas where letra='C';

select letra, sum(monto) total from facturas group by letra;
select letra, sum(monto) total from facturas group by letra having sum(monto)>3500;
/*
		letra		total
        A			4251
        B 			3600
        C			3200
*/

select provincia, count(*) cantidad from padron group by provincia;
select provincia, ciudad, count(*) cantidad from padron group by provincia, ciudad;

-- subqueries
select max(precio) from articulos;			-- 1311.54
select * from articulos where precio=1311.54;
select * from articulos where precio=(select max(precio) from articulos);





INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Calle Falsa 123', 'Cliente frecuente.'),
('María', 'Gómez', '20-23456789-0', 'Av. Siempre Viva 456', 'Interesada en promociones.'),
('Carlos', 'López', '20-34567890-1', 'Calle de la Paz 789', 'Solicitó información sobre productos.'),
('Ana', 'Martínez', '20-45678901-2', 'Paseo del Río 321', 'Prefiere contacto por email.'),
('Luis', 'Hernández', '20-56789012-3', 'Calle del Sol 654', 'Llamar para confirmar pedido.'),
('Laura', 'Rodríguez', '20-67890123-4', 'Calle de la Luna 987', 'Satisfecha con el servicio.'),
('Pedro', 'Fernández', '20-78901234-5', 'Av. Libertador 135', 'Requiere atención especial.'),
('Lucía', 'García', '20-89012345-6', 'Calle del Mar 246', 'Solicitó una reunión.'),
('Javier', 'Sánchez', '20-90123456-7', 'Calle de la Ciudad 357', 'Interesado en nuevas ofertas.'),
('Sofía', 'Díaz', '20-01234567-8', 'Calle de la Esperanza 468', 'Cliente leal desde hace años.'),
('Diego', 'Morales', '20-12345678-9', 'Calle del Bosque 579', 'Requiere seguimiento.'),
('Natalia', 'Vázquez', '20-23456789-0', 'Calle de los Árboles 680', 'Interesada en descuentos.'),
('Martín', 'Castro', '20-34567890-1', 'Calle de la Nieve 791', 'Requiere atención al cliente.'),
('Verónica', 'Ríos', '20-45678901-2', 'Calle de la Alegría 802', 'Satisfecha con la compra.'),
('Gabriel', 'Jiménez', '20-56789012-3', 'Calle de la Amistad 913', 'Requiere información adicional.'),
('Carla', 'Cruz', '20-67890123-4', 'Calle del Amor 024', 'Interesada en productos nuevos.'),
('Fernando', 'Hidalgo', '20-78901234-5', 'Calle de la Luz 135', 'Cliente VIP.'),
('Isabel', 'Ruiz', '20-89012345-6', 'Calle del Viento 246', 'Requiere atención personalizada.'),
('Andrés', 'Mena', '20-90123456-7', 'Calle del Cielo 357', 'Solicitó un cambio de producto.'),
('Clara', 'Salas', '20-01234567-8', 'Calle del Agua 468', 'Interesada en asesoría.'),
('Diego', 'Ortega', '20-12345678-9', 'Calle del Fuego 579', 'Requiere seguimiento.'),
('Patricia', 'Alvarez', '20-23456789-0', 'Calle de las Flores 680', 'Cliente frecuente.'),
('Hugo', 'Palacios', '20-34567890-1', 'Calle de los Sueños 791', 'Interesado en promociones.'),
('Mariana', 'Bermúdez', '20-45678901-2', 'Calle de la Música 802', 'Solicitó información sobre productos.'),
('Raúl', 'Soto', '20-56789012-3', 'Calle del Silencio 913', 'Prefiere contacto por email.'),
('Paola', 'Córdoba', '20-67890123-4', 'Calle del Sol 024', 'Llamar para confirmar pedido.'),
('Jorge', 'Salazar', '20-78901234-5', 'Calle de la Vida 135', 'Requiere atención especial.'),
('Cecilia', 'Núñez', '20-89012345-6', 'Calle del Reloj 246', 'Solicitó una reunión.'),
('Ernesto', 'Maldonado', '20-90123456-7', 'Calle de la Tierra 357', 'Interesado en nuevas ofertas.'),
('Silvia', 'Bustos', '20-01234567-8', 'Calle de la Esperanza 468', 'Cliente leal desde hace años.'),
('Fabio', 'Sierra', '20-12345678-9', 'Calle del Miedo 579', 'Requiere seguimiento.'),
('Teresa', 'Cano', '20-23456789-0', 'Calle de la Mariposa 680', 'Interesada en descuentos.'),
('Ricardo', 'Paz', '20-34567890-1', 'Calle de la Libertad 791', 'Requiere atención al cliente.'),
('Marisol', 'Zúñiga', '20-45678901-2', 'Calle de la Verdad 802', 'Satisfecha con la compra.'),
('Alberto', 'Ceballos', '20-56789012-3', 'Calle del Fuego 913', 'Requiere información adicional.'),
('Evelyn', 'Soto', '20-67890123-4', 'Calle de la Paz 024', 'Interesada en productos nuevos.'),
('Pablo', 'Sierra', '20-78901234-5', 'Calle de la Luz 135', 'Cliente VIP.'),
('Nora', 'Moreno', '20-89012345-6', 'Calle de la Amistad 246', 'Requiere atención personalizada.'),
('Arturo', 'Bermúdez', '20-90123456-7', 'Calle del Amor 357', 'Solicitó un cambio de producto.'),
('Luciana', 'Montoya', '20-01234567-8', 'Calle del Viento 468', 'Interesada en asesoría.'),
('Matías', 'López', '20-12345678-9', 'Calle del Fuego 579', 'Requiere seguimiento.'),
('Gabriela', 'Reyes', '20-23456789-0', 'Calle de las Estrellas 680', 'Cliente frecuente.'),
('Felipe', 'Carvajal', '20-34567890-1', 'Calle de los Ángeles 791', 'Interesado en promociones.'),
('Ana', 'Hernández', '20-45678901-2', 'Calle de la Vida 802', 'Solicitó información sobre productos.'),
('Samuel', 'Galindo', '20-56789012-3', 'Calle de los Ríos 913', 'Prefiere contacto por email.'),
('Mónica', 'Rivas', '20-67890123-4', 'Calle del Sol 024', 'Llamar para confirmar pedido.'),
('Andrés', 'Duarte', '20-78901234-5', 'Calle de la Luna 135', 'Requiere atención especial.'),
('Sandra', 'Córdova', '20-89012345-6', 'Calle del Mar 246', 'Solicitó una reunión.'),
('Luis', 'Salas', '20-90123456-7', 'Calle de la Amistad 357', 'Interesado en nuevas ofertas.'),
('Claudia', 'Vega', '20-01234567-8', 'Calle de la Esperanza 468', 'Cliente leal desde hace años.'),
('Ricardo', 'Hernández', '20-12345678-9', 'Calle del Bosque 579', 'Requiere seguimiento.'),
('Estela', 'Mena', '20-23456789-0', 'Calle de la Paz 680', 'Interesada en descuentos.'),
('Sergio', 'Pacheco', '20-34567890-1', 'Calle de la Libertad 791', 'Requiere atención al cliente.'),
('Patricia', 'Mendoza', '20-45678901-2', 'Calle de la Verdad 802', 'Satisfecha con la compra.'),
('Ricardo', 'Ruiz', '20-56789012-3', 'Calle del Silencio 913', 'Requiere información adicional.'),
('Fabiola', 'Cruz', '20-67890123-4', 'Calle de la Alegría 024', 'Interesada en productos nuevos.'),
('Diego', 'Cáceres', '20-78901234-5', 'Calle de la Luz 135', 'Cliente VIP.'),
('Nicolás', 'Mora', '20-89012345-6', 'Calle de la Amistad 246', 'Requiere atención personalizada.'),
('Gabriel', 'Sánchez', '20-90123456-7', 'Calle del Amor 357', 'Solicitó un cambio de producto.'),
('Teresa', 'González', '20-01234567-8', 'Calle del Viento 468', 'Interesada en asesoría.'),
('Fernando', 'Pérez', '20-12345678-9', 'Calle del Fuego 579', 'Requiere seguimiento.'),
('Lucía', 'Salazar', '20-23456789-0', 'Calle de las Flores 680', 'Cliente frecuente.'),
('Hugo', 'Díaz', '20-34567890-1', 'Calle de los Sueños 791', 'Interesado en promociones.'),
('Claudia', 'Martínez', '20-45678901-2', 'Calle de la Música 802', 'Solicitó información sobre productos.'),
('Luis', 'Cano', '20-56789012-3', 'Calle del Silencio 913', 'Prefiere contacto por email.'),
('Patricia', 'Ríos', '20-67890123-4', 'Calle del Sol 024', 'Llamar para confirmar pedido.'),
('Victor', 'Sierra', '20-78901234-5', 'Calle de la Vida 135', 'Requiere atención especial.'),
('Carmen', 'Vázquez', '20-89012345-6', 'Calle de la Luz 246', 'Solicitó una reunión.'),
('Ramón', 'Moreno', '20-90123456-7', 'Calle de la Amistad 357', 'Interesado en nuevas ofertas.'),
('Gonzalo', 'Hidalgo', '20-01234567-8', 'Calle de la Esperanza 468', 'Cliente leal desde hace años.');





-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.

-- 2- Agregar el campo patente despues del campo modelo.

-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
-- 	b. obtener el precio mínimo.
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
-- 	d. obtener el precio promedio.
-- 	e. obtener el precio promedio del año 2016.
-- 	f. obtener la cantidad de autos.
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
-- 	h. obtener la cantidad de autos que hay en cada año.
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
-- 	j. obtener la suma de precios y el promedio de precios según marca.
--  k. informar los autos con el menor precio.
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
--  m. listar los autos ordenados ascendentemente por marca,modelo,año.
--  n. contar cuantos autos hay de cada marca.
--  o. borrar los autos del siglo pasado.

        
        
