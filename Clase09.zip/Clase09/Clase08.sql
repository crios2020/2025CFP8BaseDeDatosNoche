use negocio;
show tables;
describe clientes;
describe facturas;
describe articulos;
select * from clientes;
select * from facturas;
select * from articulos;

-- Agregamos en facturas el campo clave foranea (Foreign Key)
alter table facturas add codigo int; 

-- Cargamos un clientes a la factura a 1001
update facturas set codigo=null where letra='A' and numero=1001;
-- update facturas set codigo=4545 where letra='A' and numero=1001;

-- Agregamos la restricción de integridad referencial
alter table facturas 
	add constraint fk_facturas_codigo_cliente
    foreign key(codigo)
    references clientes(codigo);
    
select * from facturas;
select * from clientes;
update facturas set codigo=41 where letra='A';
update facturas set codigo=42 where letra='B';
update facturas set codigo=43 where letra='C';
-- *******************************************************************
-- 				LUNES 6/10 No vengo!!!!!!!!
-- *******************************************************************


-- Consulta del producto cartesiano
select * from clientes, facturas;
select count(*) cantidad from clientes;				-- 	81
select count(*) cantidad from facturas;				--   5
select 81*5;										-- 405
select count(*) cantidad from clientes,facturas;	-- 405

-- Consulta de producto relacionado
select * from clientes, facturas where clientes.codigo=facturas.codigo;

-- uso de aleas
select * from clientes c, facturas f where c.codigo=f.codigo;

-- Uso del join
select * from clientes c join facturas f on c.codigo=f.codigo;

select * from clientes;
-- Que compro Juan Pérez?
select c.codigo, c.nombre, c.apellido, letra, numero, fecha, monto 
	from clientes c join facturas f on c.codigo=f.codigo
    where c.nombre='Juan' and c.apellido='Pérez';
insert into facturas (letra,numero,fecha,monto,codigo) values
		('A',2001,curdate(),5500,35);





