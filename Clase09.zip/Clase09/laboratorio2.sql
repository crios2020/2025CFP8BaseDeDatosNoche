-- Uso de JOIN
-- Usando la base de datos negocio2 (solo tablas clientes y facturas).
use negocio;
-- 1-	Informar que clientes (codigo, nombre, apellido) han comprado en el día de hoy.
select distinct c.codigo, nombre, apellido 
	from clientes c join facturas f on c.codigo=f.codigo
    where fecha=curdate();
-- 2-	Informar la suma de los montos de cada cliente (código,nombre,apellido,total_comprado).
select c.codigo, nombre, apellido, sum(monto) total_comprado 
	from clientes c join facturas f on c.codigo=f.codigo 
    group by c.codigo;
-- 3-	Informar cual es el cliente que más ha comprado (codigo, nombre, apellido).
select c.codigo, nombre, apellido, sum(monto) total_comprado
	from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo 
    order by total_comprado desc
    limit 1;
select c.codigo, nombre, apellido, sum(monto) total_comprado
	from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo 
    having total_comprado=(
		select sum(monto) total_comprado
			from clientes c join facturas f on c.codigo=f.codigo
			group by c.codigo 
			order by total_comprado desc
			limit 1
    );
-- 4-	Informar la cantidad de facturas de cada cliente (codigo, nombre, apellido,cantidad_facturas).
select c.codigo, nombre, apellido, count(*) cantidad_facturas
	from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo;
-- 5-	Informar quienes compraron el primer día de ventas (codigo, nombre, apellido).
select distinct c.codigo, nombre, apellido, fecha 
	from clientes c join facturas f on c.codigo=f.codigo
    where fecha=(select min(fecha) from facturas);
-- 6-	Informar que compro el cliente Juan Perez (letra,nro,fecha,monto).
select c.codigo, nombre, apellido, letra, numero, fecha, monto 
	from clientes c join facturas f on c.codigo=f.codigo
    where nombre='Juan' and apellido='Perez';

-- ********************************************************
--              Lunes 13/10  hay clases
-- ********************************************************

-- Join Muchos a Muchos
-- Creamos la tabla detalles
create table detalles(
    letra char(1),
    numero int,
    codigo int,
    cantidad int,
    primary key(letra, numero, codigo)
);

alter table detalles
	add constraint fk_detalles_facturas
    foreign key (letra,numero)
    references facturas(letra,numero);

alter table detalles
	add constraint fk_detalles_articulos
    foreign key(codigo)
    references articulos(codigo);

select * from facturas;
select * from articulos;
insert into detalles values
	('A',1001,1,5),
    ('A',1001,2,5),
    ('A',1002,4,50),
    ('B',2002,3,15),
    ('C',3003,1,11);
    
-- consulta del producto cartesiano
select * from clientes, facturas, detalles, articulos;
select count(*) cantidad from clientes;						-- 81
select count(*) cantidad from facturas;						-- 6
select count(*) cantidad from detalles;						-- 5
select count(*) cantidad from articulos;					-- 5
select 81*6*5*5;											-- 12150
select count(*) from clientes, facturas, detalles, articulos;	-- 12150

-- consulta del producto relacionado
select * from clientes c join facturas f on c.codigo=f.codigo
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo;
select count(*) cantidad											-- 5
		from clientes c join facturas f on c.codigo=f.codigo
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo;

-- Uso de JOIN

-- Usando la base de datos negocio2 (usando todas las tablas).

-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
-- 2- Informar que articulos compro 'Juan Perez'.
-- 3- Informar cuantas lamparas se vendieron.
-- 4- Informar cuantas unidades se vendieron en total en cada articulo.
-- 5- Informar la lista de artículos vendidos el día de hoy.
-- 6- Informar la lista de artículos vendidos en este mes.
-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.













