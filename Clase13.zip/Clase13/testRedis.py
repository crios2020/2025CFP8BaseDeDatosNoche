print("Hoy es Miércoles!")

# Para instalar los drivers de redis
# pip install redis                     en windows
# sudo apt install python3-redis        en linux

import redis
import json

r = redis.Redis(
    host='redis-16110.c99.us-east-1-4.ec2.cloud.redislabs.com',
    port=16110,
    decode_responses=True,
    username="test",
    password="Admin_1234",
)

print(r.ping())

r.set('curso','Base de Datos')      # guardar
print(r.get('curso'))               # leer

r.set('computadora0','Carlos')
print(r.get('computadora0'))
print(r.get('computadora10'))

r.delete('foo')

#recorro todas las llaves
print("-------------------------------")
for key in r.scan_iter("*"):
    #print(key)
    print(key,' - ',r.get(key))

#recorro solo las computadoras
print("-------------------------------")
for key in r.scan_iter("computadora*"):
    #print(key)
    print(key,' - ',r.get(key))

libro01 = {
    "isbn": "978-84-376-0494-2",
    "titulo": "Cien años de soledad",
    "autor": "Gabriel García Márquez",
    "año_publicacion": 1967,
    "editorial": "Editorial Sudamericana",
    "genero": ["Novela", "Realismo mágico", "Literatura latinoamericana"],
    "paginas": 471,
    "idioma": "español",
    "sinopsis": "Cien años de soledad es una novela del escritor colombiano Gabriel García Márquez...",
    "portada": "https://example.com/portadas/cien-anios-soledad.jpg",
    "precio": 18.90,
    "disponible": True,
    "calificacion_promedio": 4.8,
    "etiquetas": ["clásico", "premio nobel", "boom latinoamericano"]
}
clave = "libro_01"
r.set(clave, json.dumps(libro01, ensure_ascii=False, indent=2))


#recorro todas las llaves
print("-------------------------------")
for key in r.scan_iter("*"):
    #print(key)
    print(key,' - ',r.get(key))

print("-------------------------------")
print(r.get("libro_01"))