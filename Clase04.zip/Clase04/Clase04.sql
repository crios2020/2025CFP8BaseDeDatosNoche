
-- Laboratorio 3

-- 1 - Ingrese a la base de datos negocio.
use negocio;
-- 2 - Ingrese 5 registros aleatorios en cada tabla.
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 123', 'Cliente frecuente, compras mensuales.'),
('María', 'González', '20-98765432-1', 'Calle Falsa 456', 'Interesada en productos nuevos.'),
('Carlos', 'López', '20-13579246-8', 'Paseo de la Reforma 789', 'Solicitó información sobre descuentos.'),
('Ana', 'Martínez', '20-24681357-2', 'Calle de la Amistad 321', 'Prefiere atención personalizada.'),
('Luis', 'Ramírez', '20-11122233-4', 'Boulevard de los Sueños 654', 'Reclamo por servicio anterior.');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 1001, '2023-01-15', 2500.75),
('B', 2002, '2023-02-20', 1500.50),
('C', 3003, '2023-03-10', 3200.00),
('A', 1002, '2023-04-05', 1750.25),
('B', 2003, '2023-05-18', 2100.40);

INSERT INTO articulos (nombre, precio, stock) VALUES
('Laptop', 1200.50, 15),
('Teléfono Móvil', 800.99, 30),
('Auriculares Bluetooth', 150.75, 50),
('Teclado Mecánico', 120.00, 20),
('Monitor 24"', 300.00, 10);

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 100
select * from articulos where precio>100;
-- b-	artículos con precio entre 20 y 40 (usar < y >)
select * from articulos where precio>=20 and precio<=40;
-- c-	artículos con precio entre 40 y 60 (usar BETWEEN)
select * from articulos where precio between 40 and 60;
-- d-	artículos con precio = 20 y stock mayor a 30
select * from articulos where precio=20 and stock>=30;
-- e-	artículos con precio (12,20,30) no usar IN
select * from articulos where precio=12 or precio=20 or precio=30;
-- f-	artículos con precio (12,20,30) usar el IN
select * from articulos where precio in (12, 20, 30);
-- g-	artículos que su precio no sea (12,20,30)
select * from articulos where precio not in (12, 20, 30);
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
select codigo, nombre, precio, round(precio*1.21,2) precio_con_iva, stock from articulos
	where round(precio*1.21,2)>100;
-- i-   listar nombre y descripción de los artículos que no cuesten $100
select nombre from articulos where precio!=100;
-- j- 	artículos con nombre que contengan la cadena 'lampara' (usar like)
select * from articulos where nombre like '%lampara%';
-- k-   artículos que su precio sea menor que 200 y en su nombre no contenga la letra 'a'
select * from articulos where precio<200 and nombre not like '%a%';

-- 	2- Listar los artículos ordenados por precio de mayor a menor, y si hubiera precio iguales deben 
--     quedar ordenados por nombre.
select * from articulos order by precio desc, nombre;
-- 	3- Listar todos los artículos incluyendo una columna denominada precio con IVA, 
--     la cual deberá tener el monto con el iva del producto.
select codigo, nombre, precio, round(precio*1.21,2) precio_iva, stock from articulos; 
-- 	4- Listar todos los artículos incluyendo una columna denominada 'cantidad de cuotas' 
--     y otra 'valor de cuota', la cantidad es fija y es 3, 
--     el valor de cuota corresponde a 1/3 del monto con un 5% de interés.
select codigo, nombre, precio, 3 cantidad_de_cuotas, round(precio/3*1.05) valor_cuota, stock 
		from articulos;
        
        
-- Comando DML Insert

-- Insert normal con declaración de campos 			ANSI SQL
insert into clientes (nombre,apellido,direccion) values 
		('Ana','Sosa','Lima 333');
insert into clientes (apellido,direccion,nombre) values
		('Segovia','Peru 737','Ricardo');

-- Insert abreviado sin declaración de campos		ANSI SQL
insert into clientes values 
		(null,'Miguel','Mondino','787987','viel 222','');

-- Insert masivo									ANSI
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 123', 'Cliente frecuente, compras mensuales.'),
('María', 'González', '20-98765432-1', 'Calle Falsa 456', 'Interesada en productos nuevos.'),
('Carlos', 'López', '20-13579246-8', 'Paseo de la Reforma 789', 'Solicitó información sobre descuentos.'),
('Ana', 'Martínez', '20-24681357-2', 'Calle de la Amistad 321', 'Prefiere atención personalizada.'),
('Luis', 'Ramírez', '20-11122233-4', 'Boulevard de los Sueños 654', 'Reclamo por servicio anterior.');

-- Insert Set NO ANSI SQL
insert clientes set nombre='Melina', apellido='Mendez', direccion='Medrano 162';
-- Insert NO ANSI SQL
insert clientes (nombre,apellido,direccion) values 
		('Ana','Sosa','Lima 333');

-- Comando DML UPDATE				ANSI SQL
update clientes set nombre='Martin' where codigo=2;
update clientes set nombre='Juan', apellido='Molina' where codigo=3;

-- update masivo
update clientes set nombre='Maria';

-- desactivar el modo safe update
set sql_safe_updates=0;				-- =1

select * from clientes;

-- Comando DML delete				ANSI
delete from clientes where codigo=5;

-- delete masivo
delete from clientes;
        
-- Laboratorio 
-- Usando la base de datos negocio.

-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
-- 3-	Actualizar el nombre del cliente 1 a Jose.
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
-- 5-	Actualizar todos los comentarios NULL  a ''.
-- 6-	Eliminar los clientes con apellido Perez.
-- 7-	Eliminar los clientes con CUIT Terminan en 0.

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
-- 	11- Eliminar los artículos con stock menor a 0.

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.
        
        
        
        