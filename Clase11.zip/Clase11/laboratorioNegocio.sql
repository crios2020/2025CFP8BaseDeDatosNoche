-- https://dbeaver.io/download/

-- Uso de JOIN
select * from facturas;
select * from articulos;
insert into articulos values (null,'Lampara led',50,50);
select * from detalles;
insert into detalles values ('b',3,112,50);
-- Usando la base de datos negocio2 (usando todas las tablas).
use negocio;
-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
select distinct c.codigo, c.nombre, apellido
		from clientes c join facturas f on c.codigo=f.codigocliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where a.nombre like '%lampara%';
-- 2- Informar que articulos compro 'Juan Perez'.
select distinct a.codigo, a.nombre, precio, cantidad
		from clientes c join facturas f on c.codigo=f.codigocliente
		join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where c.nombre='Juan' and c.apellido='Perez';
-- 3- Informar cuantas lamparas se vendieron.
select sum(d.cantidad) cantidad_de_lamparas_vendidas 
		from detalles d join articulos a on d.codigo=a.codigo 
        where a.nombre like '%lampara%';
-- 4- Informar cuantas unidades se vendieron en total en cada articulo.
select a.codigo codigo_articulo, a.nombre, sum(d.cantidad) cantidad_vendida 
		from detalles d join articulos a on d.codigo=a.codigo 
        group by a.codigo;
-- 5- Informar la lista de artículos vendidos el día de hoy.
select distinct a.codigo, a.nombre, precio
		from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo 
        where f.fecha=curdate();
-- 6- Informar la lista de artículos vendidos en este mes.
select distinct a.codigo, a.nombre, precio
		from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo 
        where year(f.fecha)=year(curdate()) and month(f.fecha)=month(curdate());
-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.
select distinct a.codigo, a.nombre, precio, sum(d.cantidad) cantidad_vendida
		from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo 
        where year(f.fecha)=year(curdate())
        group by a.codigo;
      
select * from articulos;       
select * from facturas;
insert into facturas values
	('b',1000,curdate(),1000,1),
	('b',1001,curdate(),1000,2),
	('b',1002,curdate(),1000,4),
	('b',1003,curdate(),1000,5),
	('b',1004,curdate(),1000,1),
	('b',1005,curdate(),1000,1);

insert into detalles values
	('b',1000,1,30),
	('b',1000,3,30),
	('b',1001,4,30),
	('b',1002,2,30),
	('b',1003,1,30),
	('b',1004,5,30),
	('b',1005,5,30);

	
	
	
	
