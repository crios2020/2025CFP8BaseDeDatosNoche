-- Crear la base de datos del diagrama Reservas.png
-- Ingresar registros de prueba.
-- Realizar consultas de prueba.
DROP DATABASE if EXISTS reservas;
CREATE DATABASE reservas;
USE reservas;
CREATE TABLE Habitaciones (
    habitacion_numero INT PRIMARY KEY,
    precio_por_noche DECIMAL(10, 2),
    max_personas INT,
    tiene_cama_bebe TINYINT,
    tiene_bano TINYINT
);
CREATE TABLE Huespedes (
    huesped_id INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(45),
    apellidos VARCHAR(45),
    telefono DOUBLE,
    direccion VARCHAR(100),
    pais VARCHAR(45)
);
CREATE TABLE Reservas (
    reservas_id INT AUTO_INCREMENT PRIMARY KEY,
    inicio_fecha DATETIME,
    fin_fecha DATETIME,
    habitacion_id INT,
    huesped_id INT,
    FOREIGN KEY (habitacion_id) REFERENCES Habitaciones(habitacion_numero),
    FOREIGN KEY (huesped_id) REFERENCES Huespedes(huesped_id)
);