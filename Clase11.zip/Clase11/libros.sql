
-- -------------    -------------------     -------------     
-- - libros    -    - prestamos       -     - socios    -    
-- -------------    -------------------     -------------     
-- - codigo PK -    - documento   PK  -     - documento -
-- - titulo    -    - codigolibro PK  -     - nombre    -
-- - autor     -    - fechaprestamo   -     - domicilio -
-- -------------    - fechadevolucion -     -------------
--                  -------------------                

drop database if exists libros;
create database libros;
use libros;

drop table if exists libros;
create table libros(
  codigo int unsigned auto_increment,
  titulo varchar(40) not null,
  autor varchar(20) default 'Desconocido',
  primary key (codigo)
);

drop table if exists socios;
create table socios(
  documento char(8) not null,
  nombre varchar(30),
  domicilio varchar(30),
  primary key (documento)
);

drop table if exists prestamos;
create table prestamos(
  documento char(8) not null,
  codigolibro int unsigned,
  fechaprestamo date not null,
  fechadevolucion date,
  primary key (codigolibro,fechaprestamo)
);

insert into socios values('22333444','Juan Perez','Colon 345');
insert into socios values('23333444','Luis Lopez','Caseros 940');
insert into socios values('25333444','Ana Herrero','Sucre 120');

insert into libros values(1,'Manual de 2º grado','Molina Manuel');
insert into libros values(25,'Aprenda PHP','Oscar Mendez');
insert into libros values(42,'Martin Fierro','Jose Hernandez');

insert into prestamos values('22333444',1,'2006-08-10','2006-08-12');
insert into prestamos values('22333444',1,'2006-08-15',null);
insert into prestamos values('25333444',25,'2006-08-10','2006-08-13');
insert into prestamos values('25333444',42,'2006-08-10',null);
insert into prestamos values('25333444',25,'2006-08-15',null);
insert into prestamos values('30333444',42,'2006-08-02','2006-08-05');
insert into prestamos values('25333444',2,'2006-08-02','2006-08-05');


-- Usando la base de datos Libros responder la siguientes consultas.
use libros;
-- 1- Que libros (codigo,titulo,autor) se le prestaron a cada socio.
select s.nombre, s.documento, s.domicilio, l.codigo, l.titulo, l.autor 
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    order by s.documento;
-- 2- Lista de socios (documento,nombre,domicilio) que se le presto libros de 'java' (like '%java%')
select distinct s.nombre, s.documento, s.domicilio, l.codigo, l.titulo, l.autor 
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where l.titulo like '%java%';
-- 3- Lista de libros (codigo,titulo,autor) que no fueron devueltos (fechadevolucion is null)
select l.codigo, l.titulo, l.autor, p.fechaprestamo, p.fechadevolucion
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where fechadevolucion is null;
-- 4- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver.
select s.documento, s.nombre, s.domicilio, p.fechaprestamo, p.fechadevolucion
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where fechadevolucion is null;
-- 5- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver y cuales son los libros.
select s.documento, s.nombre, s.domicilio, p.fechaprestamo, p.fechadevolucion, 
    l.codigo, l.titulo, l.autor
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where fechadevolucion is null;
-- 6- Cantidad de libros sin devolver.
select count(*) cantidad_de_libros_devolver
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where fechadevolucion is null;
-- 7- Lista de libros que fueron prestados el día de hoy.
select l.codigo, l.titulo, l.autor
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where fechaprestamo = curdate();
-- 8- Cantidad de libros que se prestaron en este mes.
select count(*) cantidad_de_libros_prestados
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where month(fechaprestamo) = month(curdate()) and year(fechaprestamo) = year(curdate());
-- 9- Cantidad de libros que no fueron devueltos en este mes.
select count(*) cantidad_de_libros_prestados
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where month(fechaprestamo) = month(curdate()) and year(fechaprestamo) = year(curdate())
    and fechadevolucion is null;
-- 10-Cantidad de socios que se le prestaron libros en este mes.
select count(*) cantidad_de_socios_prestados
    from libros l join prestamos p on l.codigo=p.codigoLibro 
    join socios s on p.documento=s.documento 
    where month(fechaprestamo) = month(curdate()) and year(fechaprestamo) = year(curdate());