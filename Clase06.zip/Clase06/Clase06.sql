-- Active: 1756936173008@@127.0.0.1@3306@Agenda


-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.
drop database if exists vehiculos;
create database vehiculos;
use vehiculos;
create table autos(
	codigo int auto_increment primary key,
    marca varchar(25),
    modelo varchar(25),
    color varchar(25),
    anio int,
    precio double
);

-- 2- Agregar el campo patente despues del campo modelo.
alter table autos add patente varchar(12) after modelo;
describe autos;
-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
INSERT INTO autos (marca, modelo, patente, color, anio, precio) VALUES
('Toyota', 'Corolla', 'ABC123', 'Blanco', 2020, 20000.00),
('Ford', 'Focus', 'DEF456', 'Negro', 2019, 18000.00),
('Chevrolet', 'Onix', 'GHI789', 'Rojo', 2021, 15000.00),
('Honda', 'Civic', 'JKL012', 'Azul', 2022, 22000.00),
('Nissan', 'Sentra', 'MNO345', 'Gris', 2020, 17000.00),
('Volkswagen', 'Gol', 'PQR678', 'Blanco', 2018, 16000.00),
('Hyundai', 'Elantra', 'STU901', 'Negro', 2021, 19000.00),
('Kia', 'Rio', 'VWX234', 'Rojo', 2023, 21000.00),
('Mazda', '3', 'YZA567', 'Azul', 2022, 23000.00),
('Subaru', 'Impreza', 'BCD890', 'Gris', 2019, 20500.00),
('Peugeot', '208', 'EFG123', 'Blanco', 2020, 17500.00),
('Renault', 'Clio', 'HIJ456', 'Negro', 2021, 14500.00),
('Fiat', 'Punto', 'KLM789', 'Rojo', 2020, 14000.00),
('Dodge', 'Neon', 'NOP012', 'Azul', 2021, 15500.00),
('Chrysler', '300', 'QRS345', 'Gris', 2019, 24000.00),
('Mercedes-Benz', 'C-Class', 'TUV678', 'Blanco', 2020, 35000.00),
('BMW', 'X3', 'WXY901', 'Negro', 2021, 45000.00),
('Audi', 'A4', 'ZAB234', 'Rojo', 2022, 40000.00),
('Lexus', 'IS', 'CDE567', 'Azul', 2023, 37000.00),
('Volvo', 'S60', 'FGH890', 'Gris', 2020, 32000.00),
('Jaguar', 'XE', 'IJK123', 'Blanco', 2019, 50000.00),
('Land Rover', 'Evoque', 'LMN456', 'Negro', 2021, 60000.00),
('Porsche', 'Cayenne', 'OPQ789', 'Rojo', 2022, 80000.00),
('Tesla', 'Model 3', 'RST012', 'Azul', 2023, 55000.00),
('Toyota', 'Camry', 'UVW345', 'Gris', 2021, 25000.00),
('Ford', 'Escape', 'XYZ678', 'Blanco', 2020, 23000.00),
('Chevrolet', 'Malibu', 'ABC890', 'Negro', 2019, 22000.00),
('Honda', 'Accord', 'DEF123', 'Rojo', 2021, 26000.00),
('Nissan', 'Altima', 'GHI456', 'Azul', 2022, 24000.00),
('Volkswagen', 'Jetta', 'JKL789', 'Gris', 2020, 20000.00),
('Hyundai', 'Sonata', 'MNO012', 'Blanco', 2021, 21000.00),
('Kia', 'Optima', 'PQR345', 'Negro', 2022, 23000.00),
('Mazda', 'CX-5', 'STU678', 'Rojo', 2020, 28000.00),
('Subaru', 'Forester', 'VWX901', 'Azul', 2021, 29000.00),
('Peugeot', '3008', 'YZA234', 'Gris', 2022, 25000.00),
('Renault', 'Duster', 'BCD567', 'Blanco', 2021, 18000.00),
('Fiat', '500', 'EFG890', 'Negro', 2020, 12000.00),
('Dodge', 'Durango', 'HIJ123', 'Rojo', 2019, 35000.00),
('Chrysler', 'Pacifica', 'KLM456', 'Azul', 2021, 40000.00),
('Mercedes-Benz', 'GLE', 'NOP789', 'Gris', 2022, 60000.00),
('BMW', 'X5', 'QRS012', 'Blanco', 2023, 70000.00),
('Audi', 'Q5', 'TUV345', 'Negro', 2021, 55000.00),
('Lexus', 'RX', 'WXY678', 'Rojo', 2022, 65000.00),
('Volvo', 'XC90', 'ZAB901', 'Azul', 2023, 75000.00),
('Jaguar', 'F-PACE', 'CDE234', 'Gris', 2021, 80000.00),
('Land Rover', 'Defender', 'FGH567', 'Blanco', 2020, 90000.00),
('Porsche', 'Macan', 'IJK890', 'Negro', 2022, 85000.00),
('Tesla', 'Model X', 'LMN123', 'Rojo', 2023, 95000.00);

-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
select max(precio) precio_maximo from autos;
-- 	b. obtener el precio mínimo.
select min(precio) precio_minimo from autos;
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
select min(precio) precio_minimo from autos where anio between 2010 and 2018;
-- 	d. obtener el precio promedio.
select replace(round(avg(precio),2),'.',',') precio_promedio from autos;
-- 	e. obtener el precio promedio del año 2016.
select replace(round(avg(precio),2),'.',',') precio_promedio from autos where anio=2016;
-- 	f. obtener la cantidad de autos.
select count(*) cantidad from autos;
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
select count(*) cantidad from autos where precio between 235000 and 240000;
-- 	h. obtener la cantidad de autos que hay en cada año.
select anio año, count(*) cantidad from autos group by anio;
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
select anio año, count(*) cantidad, replace(round(avg(precio),2),'.',',') precio_promedio from autos group by anio; 
-- 	j. obtener la suma de precios y el promedio de precios según marca.
select marca, replace(round(sum(precio),2),'.',',') total,  replace(round(avg(precio),2),'.',',') precio_promedio 
	from autos group by marca;
--  k. informar los autos con el menor precio.
select * from autos where precio=(select min(precio) from autos);
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
select * from autos 
	where anio between 2016 and 2018 
    and precio=(select min(precio) from autos where anio between 2016 and 2018);
--  m. listar los autos ordenados ascendentemente por marca,modelo,año.
select * from autos order by marca, modelo, color;
--  n. contar cuantos autos hay de cada marca.
select marca, count(*) cantidad from autos group by marca;
--  o. borrar los autos del siglo pasado.
set sql_safe_updates=0;
delete from autos where anio<2000;


-- Laboratorio 
-- Usando la base de datos negocio.

-- Basándose en la tabla clientes realizar los siguientes puntos.
use negocio;
-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
insert into clientes values 
    (null,'Ana','Perez','645465465','Lima 222',null),
    (null,'Gabriela','Perez','789465465','Algarrobo 1041',null),
    (null,'Marino','Perez','13246','Viel 2343',null),
    (null,'Nalda','Perez','465456','Maipu 3232',null),
    (null,'Viviana','Perez','789789','Paso 1234',null);
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
insert into clientes (nombre, apellido, direccion) values 
    ('Ana','Perez','Lima 222'),
    ('Gabriela','Perez','Algarrobo 1041'),
    ('Marino','Perez','Viel 2343'),
    ('Nalda','Perez','Maipu 3232'),
    ('Viviana','Perez','Paso 1234');
-- 3-	Actualizar el nombre del cliente 1 a Jose.
update clientes set nombre='Jose' where codigo=1;
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
update clientes set nombre='Pablo', apellido='Fuentes', cuit='20-21053119-0' where codigo=3;
-- 5-	Actualizar todos los comentarios NULL  a ''.
update clientes set comentarios='' where comentarios is null;
-- 6-	Eliminar los clientes con apellido Perez.
delete from clientes where apellido='Perez';
-- 7-	Eliminar los clientes con CUIT Terminan en 0.
delete from clientes where cuit like '%0';

set sql_safe_updates=0;             -- desactiva en workbench la protección de update masivo
set sql_safe_updates=1;             -- activar la proteción de update masivo       

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
update articulos set precio=precio*1.2 where precio<=50;
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
update articulos set precio=precio*1.15 where precio>50;
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
update articulos set precio=precio*0.95 where precio>200;

update articulos set precio=round(precio,2);    -- redondea precios a 2 decimales
-- 	11- Eliminar los artículos con stock menor a 0.
delete from articulos where stock<0;
use negocio;
-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
alter table articulos add stockMinimo int;
alter table articulos add stockMaximo int;
alter table articulos drop sctokMaximo;
describe articulos;
--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
select * from articulos;

update articulos set stockMinimo=30, stockMaximo=50;
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
select codigo, nombre, precio, stock, stockMinimo, stockMaximo, 
        stockMaximo-stock cantidad_a_reponer from articulos 
        where stock<=stockMinimo;

--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
select codigo, nombre, precio, stock, precio*stock valor_de_venta from articulos;
select round(sum(precio*stock),2) valor_total_de_venta from articulos;
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.
select codigo, nombre, precio, stock, round(precio*stock*1.21,2) valor_de_venta_con_iva 
        from articulos;
select replace(round(sum(precio*stock*1.21),2),'.',',') valor_total_de_venta_con_iva 
        from articulos;

select * from facturas;
-- Funciones de agrupamientos

-- Función sum(arg)         arg:numérico
select sum(monto) from facturas;
select sum(monto) total_facturado from facturas;

select sum(monto)*0.05 comision from facturas;

-- función min(arg)         arg:numérico, texto, date
select min(monto) compra_mínima from facturas;
select min(nombre) primer_nombre from clientes;
select min(fecha) primer_factura from facturas;
select min(precio) precio_articulo_más_barato from articulos;

-- función max(arg)         arg:numérico, texto, date
select max(monto) compra_máxima from facturas;
select max(nombre) ultimo_nombre from clientes;
select max(fecha) ultima_factura from facturas;
select max(precio) precio_articulo_más_caro from articulos;

use negocio;

-- Anteultimo nombre
select distinct nombre from clientes order by nombre desc limit 1,1;

-- función avg(arg)             arg: número
select avg(monto) ticket_promedio from facturas;
select replace(round(avg(monto),2),'.',',') ticket_promedio from facturas;

-- función count(*)
select count(*) cantidad from facturas;
select count(*) cantidad from clientes;                 -- 205
select count(direccion) from clientes;                  -- 203
insert into clientes (nombre,apellido) values 
        ('Debora','Perez'),
        ('Cristian','Perez');

insert into clientes (nombre,apellido,direccion) values 
        ('Marina','Perez',''),
        ('Carlos','Perez','');
update clientes set direccion=null where codigo=15;
select * from  clientes;

-- Group By
select letra, sum(monto) total from facturas where letra='A';
select letra, sum(monto) total from facturas where letra='B';
select letra, sum(monto) total from facturas where letra='C';

select letra, sum(monto) total from facturas group by letra;

update facturas set letra='A', numero=numero*67 where letra='H';

/*
        letra           total
        A               14414
        B               7607
        C               7607

*/

select estado_civil, count(*) cantidad from padron group by estado_civil;
select provincia, count(*) cantidad from padron group by provincia;
select provincia, ciudad, count(*) cantidad from padron group by provincia, ciudad;
use negocio;
-- Uso de Having
select letra, sum(monto) total 
        from facturas 
        group by letra 
        having sum(monto)>=10000;

-- Subconsultas - Subqueries
select max(precio) from articulos;              -- 327.75
select * from articulos where precio=327.75;
select * from articulos where precio=(select max(precio) from articulos);

-- Enums
drop table facturas;
create table facturas(
        letra enum('A','B','C'),
        numero int,
        fecha date,
        monto double,
        primary key(letra, numero)
);

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 1, '2023-01-01', 150.75),
('A', 2, '2023-01-05', 200.50),
('A', 3, '2023-01-10', 175.25),
('A', 4, '2023-01-15', 300.00),
('A', 5, '2023-01-20', 120.00),
('A', 6, '2023-01-25', 450.80),
('A', 7, '2023-02-01', 230.15),
('A', 8, '2023-02-05', 320.55),
('A', 9, '2023-02-10', 180.90),
('A', 10, '2023-02-15', 210.40),
('B', 1, '2023-03-01', 300.60),
('B', 2, '2023-03-05', 250.30),
('B', 3, '2023-03-10', 175.50),
('B', 4, '2023-03-15', 400.00),
('B', 5, '2023-03-20', 150.20),
('B', 6, '2023-03-25', 275.80),
('B', 7, '2023-04-01', 320.10),
('B', 8, '2023-04-05', 180.00),
('B', 9, '2023-04-10', 290.45),
('B', 10, '2023-04-15', 220.90),
('C', 1, '2023-05-01', 500.50),
('C', 2, '2023-05-05', 400.75),
('C', 3, '2023-05-10', 600.20),
('C', 4, '2023-05-15', 350.30),
('C', 5, '2023-05-20', 450.10),
('C', 6, '2023-05-25', 300.00),
('C', 7, '2023-06-01', 275.90),
('C', 8, '2023-06-05', 150.60),
('C', 9, '2023-06-10', 225.30),
('C', 10, '2023-06-15', 180.80),
('A', 11, '2023-07-01', 500.00),
('A', 12, '2023-07-05', 600.50),
('A', 13, '2023-07-10', 750.25),
('A', 14, '2023-07-15', 400.00),
('A', 15, '2023-07-20', 950.10),
('A', 16, '2023-08-01', 800.75),
('A', 17, '2023-08-05', 1200.30),
('A', 18, '2023-08-10', 650.20),
('A', 19, '2023-08-15', 500.40),
('A', 20, '2023-08-20', 900.90),
('B', 11, '2023-09-01', 300.00),
('B', 12, '2023-09-05', 450.70),
('B', 13, '2023-09-10', 550.10),
('B', 14, '2023-09-15', 725.30),
('B', 15, '2023-09-20', 600.40),
('B', 16, '2023-10-01', 850.60),
('B', 17, '2023-10-05', 720.80),
('B', 18, '2023-10-10', 630.90),
('B', 19, '2023-10-15', 490.50),
('B', 20, '2023-10-20', 410.20),
('C', 11, '2023-11-01', 800.00),
('C', 12, '2023-11-05', 950.25),
('C', 13, '2023-11-10', 600.30),
('C', 14, '2023-11-15', 780.70),
('C', 15, '2023-11-20', 850.80),
('C', 16, '2023-12-01', 900.90),
('C', 17, '2023-12-05', 720.40),
('C', 18, '2023-12-10', 600.10),
('C', 19, '2023-12-15', 500.20),
('C', 20, '2023-12-20', 450.60);

select count(*) cantidad from facturas;

create table personas(
        codigo int AUTO_INCREMENT PRIMARY KEY,
        nombre varchar(25),
        genero enum('FEMENINO','MASCULINO','X'),
        estado_civil enum('SOLTERO','CASADO','VIUDO','DIVORCIADO')
);

-- Actividad Group by

select * from clientes;
select * from articulos;
use negocio;

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Calle Falsa 123', 'Cliente frecuente'),
('Maria', 'Gonzalez', '20-87654321-0', 'Av. Siempre Viva 742', 'Le gusta el café'),
('Luca', 'Rossi', '20-13579246-5', 'Via Roma 10', 'Interesado en promociones'),
('Sofia', 'Leroux', '20-24681357-8', 'Rue de Rivoli 45', 'Viaja frecuentemente'),
('Igor', 'Sokolov', '20-98765432-1', 'Ulitsa Leningrada 55', 'Amante de la literatura'),
('Oksana', 'Ivanova', '20-12345679-6', 'Kievskaya 22', 'Busca descuentos'),
('Piotr', 'Nowak', '20-11223344-1', 'Polska 17', 'Cliente nuevo'),
('Hans', 'Müller', '20-22334455-2', 'Berlinerstrasse 8', 'Interesado en tecnología'),
('Ana', 'Martínez', '20-33445566-3', 'Calle de la Paz 32', 'Prefiere entrega rápida'),
('Marco', 'Bianchi', '20-44556677-4', 'Via Milano 5', 'Le gusta el vino'),
('Claire', 'Dubois', '20-55667788-5', 'Avenue des Champs 12', 'Busca regalos'),
('Dmitry', 'Petrov', '20-66778899-6', 'Moscow St. 3', 'Cliente leal'),
('Elena', 'Kovalenko', '20-77889900-7', 'Kyiv Ave. 9', 'Interesada en cultura'),
('Kasia', 'Kowalska', '20-88990011-8', 'Warszawska 20', 'Le gusta viajar'),
('Stefan', 'Schmidt', '20-99001122-9', 'Münchenstrasse 15', 'Interesado en historia'),
('Lucía', 'Fernández', '20-10111213-0', 'Calle del Sol 4', 'Busca ofertas'),
('Giovanni', 'Verdi', '20-11121314-1', 'Piazza Navona 2', 'Cliente VIP'),
('Chloé', 'Martin', '20-12131415-2', 'Rue de la Paix 30', 'Le gusta el arte'),
('Alexei', 'Smirnov', '20-13141516-3', 'Nevsky Ave. 20', 'Busca productos orgánicos'),
('Tatiana', 'Petrova', '20-14151617-4', 'Lenin St. 8', 'Interesada en moda'),
('Jakub', 'Wojcik', '20-15161718-5', 'Krakowska 6', 'Amante de la música'),
('Marta', 'Sánchez', '20-16171819-6', 'Calle Montaña 11', 'Quiere recibir newsletter'),
('Alessandro', 'Conti', '20-17181920-7', 'Corso Italia 9', 'Le gusta la pasta'),
('Émile', 'Lefèvre', '20-18192021-8', 'Boulevard Saint-Germain 18', 'Cliente habitual'),
('Vladimir', 'Ivanovich', '20-19202122-9', 'Gorky St. 1', 'Busca productos locales'),
('Natalia', 'Sidorova', '20-20212223-0', 'Kiev St. 14', 'Interesada en deportes'),
('Karol', 'Nowicki', '20-21222324-1', 'Warszawskie 33', 'Cliente amable'),
('Ralf', 'Schneider', '20-22232425-2', 'Hamburgerstrasse 7', 'Le gusta la tecnología'),
('Rosa', 'López', '20-23242526-3', 'Calle Nueva 19', 'Busca productos ecológicos'),
('Francesco', 'Gallo', '20-24252627-4', 'Via Venezia 2', 'Le gusta el gelato'),
('Juliette', 'Bernard', '20-25262728-5', 'Rue du Faubourg 25', 'Interesada en cocina'),
('Artem', 'Petrovich', '20-26272829-6', 'Tverskaya St. 12', 'Busca arte local'),
('Zinaida', 'Mikhailova', '20-27282930-7', 'Pushkin St. 4', 'Le gusta el cine'),
('Katarzyna', 'Jankowska', '20-28293031-8', 'Krakowska 45', 'Interesada en literatura'),
('Michał', 'Kowalczyk', '20-29303132-9', 'Wroclawska 21', 'Prefiere productos frescos'),
('Thomas', 'Schmitt', '20-30313233-0', 'Friedrichstrasse 16', 'Busca productos gourmet'),
('Laura', 'García', '20-31323334-1', 'Calle de la Libertad 8', 'Cliente regular'),
('Andrea', 'Ricci', '20-32333435-2', 'Via Firenze 34', 'Le gusta la moda'),
('Léa', 'Moreau', '20-33343536-3', 'Rue de l’Opéra 5', 'Busca descuentos en moda'),
('Egor', 'Vasiliev', '20-34353637-4', 'Red Square 10', 'Interesado en historia'),
('Anna', 'Vasilieva', '20-35363738-5', 'Nevsky Prospect 15', 'Le gusta la cocina'),
('Mateusz', 'Kaczmarek', '20-36373839-6', 'Poznańska 27', 'Interesado en tecnología'),
('Monika', 'Nowakowska', '20-37383940-7', 'Wrocławska 11', 'Busca ofertas'),
('Rafael', 'Silva', '20-38394041-8', 'Calle del Mar 2', 'Cliente nuevo'),
('Stefano', 'Ferrari', '20-39404142-9', 'Via Milano 8', 'Le gusta viajar'),
('Amélie', 'Laurent', '20-40414243-0', 'Rue de la Liberté 14', 'Interesada en vinos'),
('Dmitry', 'Ivanov', '20-41424344-1', 'Tverskaya St. 3', 'Cliente leal'),
('Elena', 'Semenova', '20-42434445-2', 'Kremlin St. 5', 'Busca descuentos'),
('Krzysztof', 'Zalewski', '20-43444546-3', 'Warszawska 19', 'Le gusta la música'),
('Hannah', 'Schneider', '20-44454647-4', 'Lindenstrasse 22', 'Busca productos saludables'),
('Santiago', 'Hernández', '20-45464748-5', 'Calle del Sol 13', 'Interesado en deportes'),
('Alessia', 'Romano', '20-46474849-6', 'Piazza Navona 1', 'Le gusta el arte'),
('Fiona', 'Dufour', '20-47484950-7', 'Avenue des Champs 22', 'Busca regalos'),
('Yuri', 'Fedorov', '20-48495051-8', 'Gorky St. 9', 'Cliente habitual'),
('Anna', 'Danilova', '20-49505152-9', 'Kiev St. 7', 'Interesada en moda'),
('Zbigniew', 'Pawlak', '20-50515253-0', 'Wrocławska 44', 'Le gusta viajar'),
('Lara', 'Gonzales', '20-51525354-1', 'Calle Larga 8', 'Busca descuentos'),
('Giuseppe', 'Battista', '20-52535455-2', 'Via Milano 18', 'Le gusta el vino'),
('Lucie', 'Leroux', '20-53545556-3', 'Rue de la Paix 7', 'Interesada en cocina'),
('Nikita', 'Ivanovich', '20-54555657-4', 'Sovetskaya St. 11', 'Cliente leal'),
('Tatiana', 'Sidorova', '20-55565758-5', 'Kiev St. 6', 'Busca productos locales'),
('Marek', 'Kaczynski', '20-56575859-6', 'Warszawska 32', 'Le gusta la música'),
('Anja', 'Schmidt', '20-57585960-7', 'Berlinerstrasse 4', 'Interesada en tecnología'),
('Clara', 'Seidel', '20-58606061-8', 'Hamburgerstrasse 16', 'Busca productos gourmet'),
('Paolo', 'Conti', '20-59616162-9', 'Corso Italia 3', 'Le gusta la pasta'),
('Abigail', 'Smith', '20-60616263-0', 'Calle Primavera 14', 'Interesada en arte'),
('Oleg', 'Petrov', '20-61626364-1', 'St. Petersburg 8', 'Cliente nuevo'),
('Nina', 'Kovalenko', '20-62636465-2', 'Kiev St. 4', 'Le gusta la cocina'),
('Filip', 'Wojcik', '20-63646566-3', 'Krakowska 29', 'Interesado en historia');

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 123', 'Cliente frecuente'),
('Ana', 'García', '20-23456789-0', 'Calle Falsa 456', 'Interesada en productos nuevos'),
('Luis', 'Martínez', '20-34567890-1', 'Av. Libertador 789', 'Solicitó información de precios'),
('María', 'Lopez', '20-45678901-2', 'Calle 7 321', 'Requiere atención especial'),
('Carlos', 'Sánchez', '20-56789012-3', 'Av. de Mayo 654', 'Cliente regular'),
('Laura', 'Hernández', '20-67890123-4', 'Calle 4 987', 'Compras grandes'),
('Jorge', 'González', '20-78901234-5', 'Av. Corrientes 135', 'Reclamo en curso'),
('Sofía', 'Díaz', '20-89012345-6', 'Calle 8 246', 'Requiere seguimiento'),
('Ricardo', 'Ramírez', '20-90123456-7', 'Av. Rivadavia 369', 'Interesado en descuentos'),
('Natalia', 'Torres', '20-01234567-8', 'Calle 10 147', 'Cliente VIP'),
('Fernando', 'Flores', '20-12345678-9', 'Av. San Martín 258', 'No tiene comentarios'),
('Elena', 'Vázquez', '20-23456789-0', 'Calle 12 369', 'Solicitó una reunión'),
('Pablo', 'Jiménez', '20-34567890-1', 'Av. Belgrano 456', 'Interesado en colaboraciones'),
('Marta', 'Mendoza', '20-45678901-2', 'Calle 14 579', 'Cliente nuevo'),
('Ezequiel', 'Cruz', '20-56789012-3', 'Av. Cabildo 689', 'Requiere atención al cliente'),
('Patricia', 'Castro', '20-67890123-4', 'Calle 16 798', 'Interés en productos premium'),
('Victor', 'Rojas', '20-78901234-5', 'Av. 9 de Julio 789', 'Preguntó por envíos'),
('Cecilia', 'Salazar', '20-89012345-6', 'Calle 18 890', 'Cliente leal'),
('Diego', 'Núñez', '20-90123456-7', 'Av. Pueyrredón 901', 'Solicitó una cotización'),
('Raúl', 'García', '20-01234567-8', 'Calle 20 123', 'No tiene comentarios'),
('Carla', 'Soto', '20-12345678-9', 'Av. San Juan 234', 'Interesada en promociones'),
('Adriana', 'Márquez', '20-23456789-0', 'Calle 22 345', 'Cliente frecuente'),
('José', 'Vega', '20-34567890-1', 'Av. Rivadavia 456', 'Requiere productos personalizados'),
('Silvia', 'Benítez', '20-45678901-2', 'Calle 24 567', 'Interés en ofertas'),
('Fernando', 'Aguirre', '20-56789012-3', 'Av. Libertador 678', 'Cliente regular'),
('Lucía', 'Cordero', '20-67890123-4', 'Calle 26 789', 'Solicita seguimiento'),
('Andrés', 'Maldonado', '20-78901234-5', 'Av. Maipú 890', 'Interesado en descuentos'),
('Brenda', 'Fuentes', '20-89012345-6', 'Calle 28 901', 'No tiene comentarios'),
('Marcos', 'Téllez', '20-90123456-7', 'Av. San Martín 123', 'Solicito más información'),
('Julieta', 'Salinas', '20-01234567-8', 'Calle 30 234', 'Cliente leal'),
('Nicolás', 'Paz', '20-12345678-9', 'Av. Almagro 345', 'Requiere atención especial'),
('Verónica', 'Ponce', '20-23456789-0', 'Calle 32 456', 'Interesada en productos nuevos'),
('Gustavo', 'Cáceres', '20-34567890-1', 'Av. Santa Fe 567', 'Reclamó un pedido'),
('Martín', 'Bermúdez', '20-45678901-2', 'Calle 34 678', 'Cliente frecuente'),
('Alicia', 'Sánchez', '20-56789012-3', 'Av. Cramer 789', 'Solicitó una reunión'),
('Felipe', 'Sierra', '20-67890123-4', 'Calle 36 890', 'Interesado en colaboraciones'),
('Claudia', 'Ríos', '20-78901234-5', 'Av. Rivadavia 901', 'Cliente nuevo'),
('Esteban', 'López', '20-89012345-6', 'Calle 38 123', 'Requiere atención al cliente'),
('Carolina', 'Pérez', '20-90123456-7', 'Av. Rivadavia 234', 'Interés en productos premium'),
('Hernán', 'Figueroa', '20-01234567-8', 'Calle 40 345', 'Solicitó una cotización'),
('Rocío', 'Castillo', '20-12345678-9', 'Av. Belgrano 456', 'No tiene comentarios'),
('Joaquín', 'Salas', '20-23456789-0', 'Calle 42 567', 'Interesada en promociones'),
('Luciano', 'Cordero', '20-34567890-1', 'Av. Cabildo 678', 'Cliente regular'),
('Alejandra', 'Giménez', '20-45678901-2', 'Calle 44 789', 'Requiere productos personalizados'),
('Diego', 'Rivera', '20-56789012-3', 'Av. San Juan 890', 'Interés en ofertas'),
('Tatiana', 'Valdez', '20-67890123-4', 'Calle 46 901', 'Cliente leal'),
('Nicolás', 'Ceballos', '20-78901234-5', 'Av. Concepción 123', 'Solicito más información'),
('Patricio', 'Salvador', '20-89012345-6', 'Calle 48 234', 'Requiere atención especial'),
('Fernando', 'Mora', '20-90123456-7', 'Av. Italia 345', 'Interesada en productos nuevos'),
('Milagros', 'Pantoja', '20-01234567-8', 'Calle 50 456', 'Reclamó un pedido'),
('Cristian', 'Guzmán', '20-12345678-9', 'Av. Corrientes 567', 'Cliente frecuente'),
('Lorena', 'Alvarado', '20-23456789-0', 'Calle 52 678', 'Solicitó una reunión'),
('Mario', 'Cortés', '20-34567890-1', 'Av. San Lorenzo 789', 'Interesado en colaboraciones'),
('Estefanía', 'López', '20-45678901-2', 'Calle 54 890', 'Cliente nuevo'),
('Raúl', 'Figueroa', '20-56789012-3', 'Av. Independencia 901', 'Requiere atención al cliente'),
('Sandra', 'Pérez', '20-67890123-4', 'Calle 56 123', 'Interés en productos premium'),
('Carlos', 'Sierra', '20-78901234-5', 'Av. Rivadavia 234', 'Solicitó una cotización'),
('Verónica', 'Solís', '20-89012345-6', 'Calle 58 345', 'No tiene comentarios'),
('Hugo', 'Maldonado', '20-90123456-7', 'Av. San Martín 456', 'Interesada en promociones'),
('Claudia', 'González', '20-01234567-8', 'Calle 60 567', 'Cliente regular'),
('Ignacio', 'Ramírez', '20-12345678-9', 'Av. Santa Fe 678', 'Requiere productos personalizados'),
('Silvia', 'Hernández', '20-23456789-0', 'Calle 62 789', 'Interés en ofertas'),
('Gonzalo', 'Torres', '20-34567890-1', 'Av. Rivadavia 890', 'Cliente leal'),
('Mónica', 'Cruz', '20-45678901-2', 'Calle 64 901', 'Solicito más información'),
('Leonardo', 'Martínez', '20-56789012-3', 'Av. Almagro 123', 'Requiere atención especial'),
('Jessica', 'Salas', '20-67890123-4', 'Calle 66 234', 'Interesada en productos nuevos'),
('Sergio', 'Sánchez', '20-78901234-5', 'Av. San Juan 345', 'Reclamó un pedido'),
('Ana', 'Vázquez', '20-89012345-6', 'Calle 68 456', 'Cliente frecuente'),
('Gabriel', 'Paredes', '20-90123456-7', 'Av. Corrientes 567', 'Solicitó una reunión'),
('Vanessa', 'Cordero', '20-01234567-8', 'Calle 70 678', 'Interesado en colaboraciones'),
('Emilio', 'Ramírez', '20-12345678-9', 'Av. Independencia 789', 'Cliente nuevo'),
('Nadia', 'López', '20-23456789-0', 'Calle 72 890', 'Requiere atención al cliente'),
('Julián', 'Díaz', '20-34567890-1', 'Av. Santa Fe 901', 'Interés en productos premium'),
('Rita', 'Maldonado', '20-45678901-2', 'Calle 74 123', 'Solicitó una cotización'),
('Mauricio', 'Núñez', '20-56789012-3', 'Av. Rivadavia 234', 'No tiene comentarios'),
('María', 'González', '20-67890123-4', 'Calle 76 345', 'Interesada en promociones'),
('Joaquín', 'Cruz', '20-78901234-5', 'Av. San Martín 456', 'Cliente regular'),
('Rocío', 'Figueroa', '20-89012345-6', 'Calle 78 567', 'Requiere productos personalizados'),
('Diana', 'Vallejo', '20-90123456-7', 'Av. San Juan 678', 'Interés en ofertas'),
('Pablo', 'Sierra', '20-01234567-8', 'Calle 80 789', 'Cliente leal'),
('Gabriela', 'Alvarez', '20-12345678-9', 'Av. Santa Fe 890', 'Solicito más información'),
('Andrés', 'Mendoza', '20-23456789-0', 'Calle 82 901', 'Requiere atención especial'),
('María', 'Salinas', '20-34567890-1', 'Av. Corrientes 123', 'Interesada en productos nuevos'),
('Fernando', 'Cáceres', '20-45678901-2', 'Calle 84 234', 'Reclamó un pedido'),
('Elena', 'Martínez', '20-56789012-3', 'Av. Rivadavia 345', 'Cliente frecuente'),
('Santiago', 'Torres', '20-67890123-4', 'Calle 86 456', 'Solicitó una reunión'),
('Joaquín', 'Ramírez', '20-78901234-5', 'Av. San Martín 567', 'Interesado en colaboraciones');
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Calle Falsa 123', 'Cliente frecuente'),
('Marco', 'Bianchi', '20-23456789-0', 'Via Roma 45', 'Interesado en promociones'),
('Sofia', 'Leroux', '20-34567890-1', 'Rue de Rivoli 12', 'Viaja frecuentemente'),
('Igor', 'Sokolov', '20-45678901-2', 'Lenin St. 22', 'Amante de la literatura'),
('Oksana', 'Ivanova', '20-56789012-3', 'Kievskaya 15', 'Busca descuentos'),
('Piotr', 'Nowak', '20-67890123-4', 'Polska 10', 'Cliente nuevo'),
('Hans', 'Müller', '20-78901234-5', 'Berlinerstrasse 8', 'Interesado en tecnología'),
('Ana', 'Martínez', '20-89012345-6', 'Calle de la Paz 32', 'Prefiere entrega rápida'),
('Luca', 'Rossi', '20-90123456-7', 'Via Milano 5', 'Le gusta el vino'),
('Claire', 'Dubois', '20-01234567-8', 'Avenue des Champs 20', 'Busca regalos'),
('Dmitry', 'Petrov', '20-12345679-0', 'Moscow St. 3', 'Cliente leal'),
('Elena', 'Kovalenko', '20-23456780-1', 'Kiev St. 14', 'Interesada en cultura'),
('Kasia', 'Kowalska', '20-34567891-2', 'Warszawska 22', 'Le gusta viajar'),
('Stefan', 'Schmidt', '20-45678902-3', 'Münchenstrasse 10', 'Interesado en historia'),
('Lucía', 'Fernández', '20-56789013-4', 'Calle del Sol 4', 'Busca ofertas'),
('Giovanni', 'Verdi', '20-67890124-5', 'Piazza Navona 2', 'Cliente VIP'),
('Chloé', 'Martin', '20-78901235-6', 'Rue de la Paix 30', 'Le gusta el arte'),
('Alexei', 'Smirnov', '20-89012346-7', 'Nevsky Ave. 20', 'Busca productos orgánicos'),
('Tatiana', 'Petrova', '20-90123457-8', 'Lenin St. 8', 'Interesada en moda'),
('Jakub', 'Wojcik', '20-01234568-9', 'Krakowska 6', 'Amante de la música'),
('Marta', 'Sánchez', '20-12345680-0', 'Calle Montaña 11', 'Quiere recibir newsletter'),
('Alessandro', 'Conti', '20-23456781-1', 'Corso Italia 9', 'Le gusta la pasta'),
('Émile', 'Lefèvre', '20-34567892-2', 'Boulevard Saint-Germain 18', 'Cliente habitual'),
('Vladimir', 'Ivanovich', '20-45678903-3', 'Gorky St. 1', 'Busca productos locales'),
('Natalia', 'Sidorova', '20-56789014-4', 'Kiev St. 14', 'Interesada en deportes'),
('Karol', 'Nowicki', '20-67890125-5', 'Warszawska 33', 'Cliente amable'),
('Ralf', 'Schneider', '20-78901236-6', 'Hamburgerstrasse 7', 'Le gusta la tecnología'),
('Rosa', 'López', '20-89012347-7', 'Calle Nueva 19', 'Busca productos ecológicos'),
('Francesco', 'Gallo', '20-90123458-8', 'Via Venezia 2', 'Le gusta el gelato'),
('Juliette', 'Bernard', '20-01234569-9', 'Rue du Faubourg 25', 'Interesada en cocina'),
('Artem', 'Petrovich', '20-12345681-0', 'Tverskaya St. 12', 'Busca arte local'),
('Zinaida', 'Mikhailova', '20-23456782-1', 'Pushkin St. 4', 'Le gusta el cine'),
('Katarzyna', 'Jankowska', '20-34567893-2', 'Krakowska 45', 'Interesada en literatura'),
('Michał', 'Kowalczyk', '20-45678904-3', 'Wroclawska 21', 'Prefiere productos frescos'),
('Thomas', 'Schmitt', '20-56789015-4', 'Friedrichstrasse 16', 'Busca productos gourmet'),
('Laura', 'García', '20-67890126-5', 'Calle de la Libertad 8', 'Cliente regular'),
('Andrea', 'Ricci', '20-78901237-6', 'Via Firenze 34', 'Le gusta la moda'),
('Léa', 'Moreau', '20-89012348-7', 'Rue de l’Opéra 5', 'Busca descuentos en moda'),
('Egor', 'Vasiliev', '20-90123459-8', 'Red Square 10', 'Interesado en historia'),
('Anna', 'Vasilieva', '20-01234570-9', 'Kiev St. 7', 'Le gusta la cocina'),
('Zbigniew', 'Pawlak', '20-12345682-0', 'Wrocławska 32', 'Le gusta viajar'),
('Lara', 'Gonzales', '20-23456783-1', 'Calle Larga 8', 'Busca descuentos'),
('Giuseppe', 'Battista', '20-34567894-2', 'Via Milano 18', 'Le gusta el vino'),
('Lucie', 'Leroux', '20-45678905-3', 'Rue de la Paix 7', 'Interesada en cocina'),
('Nikita', 'Ivanovich', '20-56789016-4', 'Sovetskaya St. 11', 'Cliente nuevo'),
('Tatiana', 'Sidorova', '20-67890127-5', 'Kiev St. 6', 'Le gusta la cocina'),
('Filip', 'Wojcik', '20-78901238-6', 'Krakowska 29', 'Interesado en historia');

-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.
drop database if exists vehiculos;
create database vehiculos;
use vehiculos;
create table autos(
        codigo int auto_increment primary key,
        marca varchar(25),
        modelo varchar(25),
        color varchar(25),
        anio INT,
        precio double
);
describe autos;

-- 2- Agregar el campo patente despues del campo modelo.
alter table autos add patente varchar(8) after modelo;

-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
INSERT INTO autos (marca, modelo, patente, color, anio, precio) VALUES
('Toyota', 'Corolla', 'ABC1234', 'Rojo', 2020, 20000.00),
('Ford', 'Focus', 'DEF5678', 'Azul', 2019, 18000.00),
('Chevrolet', 'Onix', 'GHI9012', 'Negro', 2021, 15000.00),
('Honda', 'Civic', 'JKL3456', 'Blanco', 2020, 22000.00),
('Nissan', 'Versa', 'MNO7890', 'Gris', 2021, 16000.00),
('Hyundai', 'Elantra', 'PQR1234', 'Rojo', 2022, 21000.00),
('Volkswagen', 'Gol', 'STU5678', 'Verde', 2018, 14000.00),
('Kia', 'Rio', 'VWX9012', 'Azul', 2019, 14500.00),
('Mazda', '3', 'YZA3456', 'Negro', 2021, 23000.00),
('Peugeot', '208', 'BCD7890', 'Blanco', 2020, 15500.00),
('Renault', 'Clio', 'EFG1234', 'Gris', 2022, 15000.00),
('Subaru', 'Impreza', 'HIJ5678', 'Rojo', 2019, 24000.00),
('Fiat', 'Punto', 'KLM9012', 'Negro', 2021, 13000.00),
('Mitsubishi', 'Lancer', 'NOP3456', 'Azul', 2018, 19000.00),
('Mercedes-Benz', 'Clase A', 'QRS7890', 'Blanco', 2022, 35000.00),
('BMW', 'Serie 1', 'TUV1234', 'Gris', 2021, 33000.00),
('Audi', 'A3', 'WXY5678', 'Rojo', 2020, 32000.00),
('Land Rover', 'Evoque', 'ZAB9012', 'Verde', 2021, 45000.00),
('Toyota', 'Camry', 'CDE3456', 'Negro', 2022, 27000.00),
('Honda', 'HR-V', 'FGH7890', 'Blanco', 2020, 24000.00),
('Kia', 'Sportage', 'IJK1234', 'Azul', 2021, 26000.00),
('Nissan', 'X-Trail', 'LMN5678', 'Gris', 2019, 23000.00),
('Ford', 'Escape', 'OPQ9012', 'Rojo', 2022, 28000.00),
('Chevrolet', 'Tracker', 'RST3456', 'Negro', 2020, 22000.00),
('Hyundai', 'Tucson', 'UVW7890', 'Blanco', 2021, 31000.00),
('Subaru', 'Forester', 'XYZ1234', 'Verde', 2022, 35000.00),
('Volkswagen', 'Tiguan', 'ABC5678', 'Azul', 2020, 34000.00),
('Mazda', 'CX-5', 'DEF9012', 'Rojo', 2021, 36000.00),
('Peugeot', '3008', 'GHI3456', 'Gris', 2022, 33000.00),
('Renault', 'Duster', 'JKL7890', 'Negro', 2019, 19000.00),
('Fiat', 'Cronos', 'MNO1234', 'Blanco', 2021, 15000.00),
('Mitsubishi', 'Outlander', 'PQR5678', 'Rojo', 2020, 30000.00),
('Mercedes-Benz', 'GLE', 'STU9012', 'Verde', 2022, 60000.00);
use vehiculos;
-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
select max(precio) precio_maximo from autos;
-- 	b. obtener el precio mínimo.
select min(precio) precio_minimo from autos;
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
select * from autos where anio between 2010 and 2018;
select min(precio) precio_minimo from autos where anio between 2010 and 2018;
-- 	d. obtener el precio promedio.
select avg(precio) precio_promedio from autos;
select replace(round(avg(precio),2),'.',',') precio_promedio from autos;
-- 	e. obtener el precio promedio del año 2016.
select replace(round(avg(precio),2),'.',',') precio_promedio from autos where anio=2016;
-- 	f. obtener la cantidad de autos.
select count(*) cantidad from autos;
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
select count(*) cantidad from autos where precio between 235000 and 240000;
-- 	h. obtener la cantidad de autos que hay en cada año.
select anio año, count(*) cantidad from autos group by anio;
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
select anio año, count(*) cantidad, replace(round(avg(precio),2),'.',',') precio_promedio 
        from autos group by anio;
-- 	j. obtener la suma de precios y el promedio de precios según marca.
select marca, replace(round(sum(precio),2),'.',',') suma_total, replace(round(avg(precio),2),'.',',') promedio 
        from autos group by marca;
--  k. informar los autos con el menor precio.
select * from autos where precio=(select min(precio) from autos);
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
select * from autos 
        where anio between 2016 and 2018 
        and precio=(select min(precio) from autos where anio between 2016 and 2018);
--  m. listar los autos ordenados ascendentemente por marca,modelo,año.
select * from autos order by marca, modelo, anio;
--  n. contar cuantos autos hay de cada marca.
select marca, count(*) cantidad from autos group by marca;

select marca, count(*) as cantidad_autos from autos group by marca order by marca;
--  o. borrar los autos del siglo pasado.
delete from autos where anio<2000;
set sql_safe_updates=0;


-- Laboratorio
-- Crear la base de datos laboratorio_06, si ya existe borrarla.

-- Crear la siguiente tabla.
create table cursos(
	codigo int,
	nombre varchar(20),
	dias varchar(10),
	inscriptos int,
	primary key(codigo)
);

insert into cursos values
	(1,'PHP','lunes',10),
	(2,'Java','lunes',5),
	(3,'Corel Draw','martes',2),
	(4,'Java','martes',5),
	(5,'MySQL','martes',5),
	(6,'Oracle','miercoles',6),
	(7,'C#.net','jueves',5),
	(8,'C#.net','viernes',4),
	(9,'PHP','lunes',10),
	(10,'C#.net','lunes',5),
	(11,'Corel Draw','martes',2),
	(12,'Oracle','martes',5),
	(13,'PHP','martes',5),
	(14,'Oracle','miercoles',6),
	(15,'C#.net','jueves',5),
	(16,'Java','viernes',4);

-- Según la tabla cursos
-- 1 - Sumar en uno la cantidad de alumnos inscriptos del curso Java de los días Lunes
-- 2 - Poner en 0 la cantidad de alumnos inscriptos de los cursos de los días Martes
-- 3 - Borrar los cursos de Java en día Martes
-- 4 - Sumar 5 inscriptos en los cursos que tengan menos de 5 alumnos inscriptos.
-- 5 - Cambiar el nombre de los cursos Java por Java 2 SE.

-- Ejercicio 2-- Crear la siguiente tabla.

create table empleados(
	codigo int auto_increment,
	nombre varchar(20) not null,
	apellido varchar(20) not null,
	seccion varchar(20),
	sueldo float,
	primary key (codigo)
);

insert into empleados (nombre,apellido,seccion,sueldo) values
	('juan','perez','administracion',72000),
	('diego','torres','ventas',35200),
	('laura','gomez','ventas',46000),
	('mario','lopez','produccion',45000),
	('dario','sanchez','administracion',86000),
	('juan','boneli','administracion',72000),
	('diego','martinez','ventas',35200),
	('laura','moretti','ventas',46000),
	('sandra','lazante','produccion',45000),
	('susana','mendez','administracion',86000);

-- 1 Cambiar al empleado Mario Lopezs de la sección administración a producción.
-- 2 Aplicar un aumento de sueldo básico del 15% a los empleados de ventas.
-- 3 Aplicar un aumento del 8% a todos los empleados de producción que tengan un
-- 		sueldo básico menor a 6000 pesos.
-- 4 Dar de baja al empleado Susana Méndez.
-- 5 Aplicar un aumento de sueldo del 4% a todos los empleados que tengan un 
-- 		básico mayor o igual a 5000 pesos.
-- 6 Aplicar un aumento de sueldo del 8% a todos los empleados que tengan un 
-- 		básico menor a 5000 pesos.
-- 7 Agregar el campo fecha de nacimiento (date) en la tabla empleados despues del campo apellido.
-- 8 Completar una fecha de nacimiento para cada empleado.
-- 9 Listar todos los campos de empleados + una columna que calcule la edad de cada empleado.


        
        
