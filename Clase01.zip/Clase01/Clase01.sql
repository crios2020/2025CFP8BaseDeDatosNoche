-- Linea de comentarios
/* Bloque de comentarios */
#comentarios NO ANSI

show databases;		-- muestra las BDs del server
-- ; es el terminador de sentencias (Obligatorio)
-- Ctrol - Enter	Ejecutamos una sentencia

SHOW DATABASES;		-- Lenguaje no case sensitive

-- borrar la base de datos clase01;
drop database if exists clase01;

-- Crear la base de datos clase01;
create database clase01;
-- CREATE DATABASE CLASE01;

use clase01;		-- activa la BD clase01;

show tables;		-- listado de tablas que hay en la bases

-- borramos la tabla clientes
drop table if exists clientes;
-- create table clientes
create table clientes(
	codigo int primary key auto_increment,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit varchar(13),
    direccion varchar(50),
    comentarios varchar(150)
);

describe clientes;		-- consulta el metadato de la tabla
select * from clientes;	-- lista los registros de la tabla

-- insertamos un registro de ejemplo
insert into clientes (nombre,apellido,cuit,direccion) values
	('Ana','Gallo','12345678','Lima 22');


